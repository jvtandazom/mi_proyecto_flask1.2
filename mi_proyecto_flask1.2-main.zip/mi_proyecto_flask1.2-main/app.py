from flask import Flask, render_template, request, redirect, url_for, jsonify
import json
import csv
import os
import sqlite3
from datetime import datetime

app = Flask(__name__)

# Configuración de rutas de archivos
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
TXT_FILE = os.path.join(BASE_DIR, 'datos', 'datos.txt')
JSON_FILE = os.path.join(BASE_DIR, 'datos', 'datos.json')
CSV_FILE = os.path.join(BASE_DIR, 'datos', 'datos.csv')
DB_FILE = os.path.join(BASE_DIR, 'database', 'usuarios.db')

# Crear directorios si no existen
os.makedirs(os.path.dirname(TXT_FILE), exist_ok=True)
os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)

# Inicializar base de datos
def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            email TEXT NOT NULL,
            fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

# Rutas básicas
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/formulario')
def formulario():
    return render_template('formulario.html')

@app.route('/resultado')
def resultado():
    return render_template('resultado.html')

# Persistencia con archivos TXT
@app.route('/guardar_txt', methods=['POST'])
def guardar_txt():
    nombre = request.form['nombre']
    email = request.form['email']
    
    with open(TXT_FILE, 'a', encoding='utf-8') as f:
        f.write(f"{nombre},{email},{datetime.now()}\n")
    
    return redirect(url_for('resultado'))

@app.route('/leer_txt')
def leer_txt():
    datos = []
    try:
        with open(TXT_FILE, 'r', encoding='utf-8') as f:
            for linea in f:
                partes = linea.strip().split(',')
                if len(partes) >= 3:
                    datos.append({
                        'nombre': partes[0],
                        'email': partes[1],
                        'fecha': partes[2]
                    })
    except FileNotFoundError:
        pass
    
    return render_template('resultado.html', datos_txt=datos)

# Persistencia con archivos JSON
@app.route('/guardar_json', methods=['POST'])
def guardar_json():
    nombre = request.form['nombre']
    email = request.form['email']
    
    datos = []
    # Leer datos existentes
    try:
        with open(JSON_FILE, 'r', encoding='utf-8') as f:
            datos = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    
    # Agregar nuevo dato
    nuevo_dato = {
        'nombre': nombre,
        'email': email,
        'fecha': datetime.now().isoformat()
    }
    datos.append(nuevo_dato)
    
    # Guardar datos
    with open(JSON_FILE, 'w', encoding='utf-8') as f:
        json.dump(datos, f, indent=4)
    
    return redirect(url_for('resultado'))

@app.route('/leer_json')
def leer_json():
    datos = []
    try:
        with open(JSON_FILE, 'r', encoding='utf-8') as f:
            datos = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    
    return render_template('resultado.html', datos_json=datos)

# Persistencia con archivos CSV
@app.route('/guardar_csv', methods=['POST'])
def guardar_csv():
    nombre = request.form['nombre']
    email = request.form['email']
    
    file_exists = os.path.isfile(CSV_FILE)
    
    with open(CSV_FILE, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(['Nombre', 'Email', 'Fecha'])
        writer.writerow([nombre, email, datetime.now().isoformat()])
    
    return redirect(url_for('resultado'))

@app.route('/leer_csv')
def leer_csv():
    datos = []
    try:
        with open(CSV_FILE, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                datos.append(row)
    except FileNotFoundError:
        pass
    
    return render_template('resultado.html', datos_csv=datos)

# Persistencia con SQLite
@app.route('/guardar_db', methods=['POST'])
def guardar_db():
    nombre = request.form['nombre']
    email = request.form['email']
    
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO usuarios (nombre, email) VALUES (?, ?)', (nombre, email))
    conn.commit()
    conn.close()
    
    return redirect(url_for('resultado'))

@app.route('/leer_db')
def leer_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM usuarios')
    usuarios = cursor.fetchall()
    conn.close()
    
    # Convertir a lista de diccionarios
    datos_db = []
    for usuario in usuarios:
        datos_db.append({
            'id': usuario[0],
            'nombre': usuario[1],
            'email': usuario[2],
            'fecha_registro': usuario[3]
        })
    
    return render_template('resultado.html', datos_db=datos_db)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)